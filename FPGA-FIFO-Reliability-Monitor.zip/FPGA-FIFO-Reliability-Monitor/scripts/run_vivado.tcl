# Vivado TCL build and implementation batch script
create_project -force fifo_reliability ./vivado_proj -part xc7a35tcpg236-1

add_files [glob ./rtl/*.v]
add_files -fileset sim_1 ./tb/tb_fifo_reliable_core.v
add_files -fileset constrs_1 ./constraints/Basys3_Artix7.xdc

set_property top top_fifo_reliability [current_fileset]
set_property top tb_fifo_reliable_core [get_filesets sim_1]

update_compile_order -fileset sources_1
update_compile_order -fileset sim_1

# Run behavioral simulation
launch_simulation
run all

# Run Synthesis and Implementation
launch_runs synth_1 -jobs 4
wait_on_run synth_1
launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1

puts "=== Implementation and Bitstream generation complete ==="
