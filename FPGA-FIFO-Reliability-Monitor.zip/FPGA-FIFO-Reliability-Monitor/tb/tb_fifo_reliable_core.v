`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Testbench: tb_fifo_reliable_core
// Verification Scenarios:
//  1. Reset & initial flag verification
//  2. Sequential write burst to test Almost-Full and Full assertion
//  3. Overflow fault injection test
//  4. Sequential read burst to test Almost-Empty and Empty assertion
//  5. Underflow fault injection test
//  6. Concurrent read and write operations
//////////////////////////////////////////////////////////////////////////////////

module tb_fifo_reliable_core;

    localparam DATA_WIDTH = 8;
    localparam ADDR_WIDTH = 4;
    localparam DEPTH      = 16;

    reg                   clk;
    reg                   rst;
    reg                   wr_en;
    reg  [DATA_WIDTH-1:0] din;
    reg                   rd_en;
    wire [DATA_WIDTH-1:0] dout;
    wire                  full;
    wire                  empty;
    wire                  almost_full;
    wire                  almost_empty;
    wire [ADDR_WIDTH:0]   word_count;
    wire                  overflow_error;
    wire                  underflow_error;
    wire                  parity_err_out;

    // Instantiate Unit Under Test (UUT)
    fifo_reliable_core #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .DEPTH(DEPTH),
        .ALMOST_FULL_THRESH(14),
        .ALMOST_EMPTY_THRESH(2)
    ) uut (
        .clk(clk),
        .rst(rst),
        .wr_en(wr_en),
        .din(din),
        .rd_en(rd_en),
        .dout(dout),
        .full(full),
        .empty(empty),
        .almost_full(almost_full),
        .almost_empty(almost_empty),
        .word_count(word_count),
        .overflow_error(overflow_error),
        .underflow_error(underflow_error),
        .parity_err_out(parity_err_out)
    );

    // 100 MHz clock generation (10 ns period)
    always #5 clk = ~clk;

    integer i;

    initial begin
        $dumpfile("tb_fifo_reliable_core.vcd");
        $dumpvars(0, tb_fifo_reliable_core);

        // Initial setup
        clk   = 0;
        rst   = 1;
        wr_en = 0;
        rd_en = 0;
        din   = 8'h00;

        #20;
        rst = 0;
        #10;

        // Verify initial state
        if (empty !== 1'b1 || word_count !== 0) begin
            $display("[FAIL] Expected EMPTY=1 at reset");
            $finish;
        end
        $display("[PASS] Reset sequence verified.");

        // Write 16 bytes sequentially
        $display("--- Writing 16 elements to FIFO ---");
        for (i = 0; i < 16; i = i + 1) begin
            @(posedge clk);
            wr_en = 1'b1;
            din   = 8'hA0 + i;
        end
        @(posedge clk);
        wr_en = 1'b0;
        din   = 8'h00;
        #10;

        if (full !== 1'b1 || word_count !== 16) begin
            $display("[FAIL] FIFO failed to reach FULL status. count=%d", word_count);
            $finish;
        end
        $display("[PASS] FIFO Full status asserted correctly.");

        // Inject Overflow Fault (Write while full)
        $display("--- Injecting Overflow Fault ---");
        @(posedge clk);
        wr_en = 1'b1;
        din   = 8'hFF;
        @(posedge clk);
        wr_en = 1'b0;
        #10;

        if (overflow_error !== 1'b1) begin
            $display("[FAIL] Overflow error flag not latched!");
            $finish;
        end
        $display("[PASS] Sticky Overflow Error asserted successfully.");

        // Read all 16 elements
        $display("--- Reading 16 elements from FIFO ---");
        for (i = 0; i < 16; i = i + 1) begin
            @(posedge clk);
            rd_en = 1'b1;
            @(posedge clk);
            rd_en = 1'b0;
            if (dout !== (8'hA0 + i)) begin
                $display("[FAIL] Data mismatch at read %0d: Expected %h, Got %h", i, (8'hA0 + i), dout);
                $finish;
            end
        end
        #10;

        if (empty !== 1'b1 || word_count !== 0) begin
            $display("[FAIL] FIFO failed to reach EMPTY status. count=%d", word_count);
            $finish;
        end
        $display("[PASS] All elements read correctly with FIFO empty asserted.");

        // Inject Underflow Fault (Read while empty)
        $display("--- Injecting Underflow Fault ---");
        @(posedge clk);
        rd_en = 1'b1;
        @(posedge clk);
        rd_en = 1'b0;
        #10;

        if (underflow_error !== 1'b1) begin
            $display("[FAIL] Underflow error flag not latched!");
            $finish;
        end
        $display("[PASS] Sticky Underflow Error asserted successfully.");

        // Concurrent Read / Write Test
        $display("--- Testing Concurrent Read and Write ---");
        @(posedge clk);
        wr_en = 1'b1;
        din   = 8'h55;
        @(posedge clk);
        wr_en = 1'b0; // 1 item inside
        #10;

        @(posedge clk);
        wr_en = 1'b1;
        din   = 8'hAA;
        rd_en = 1'b1;
        @(posedge clk);
        wr_en = 1'b0;
        rd_en = 1'b0;
        #10;

        if (dout !== 8'h55 || word_count !== 1) begin
            $display("[FAIL] Concurrent Read/Write failed.");
            $finish;
        end
        $display("[PASS] Concurrent Read/Write executed with invariant occupancy.");

        $display("=================================================");
        $display(" ALL RELIABILITY VERIFICATION TESTS PASSED (100%%) ");
        $display("=================================================");
        $finish;
    end

endmodule
