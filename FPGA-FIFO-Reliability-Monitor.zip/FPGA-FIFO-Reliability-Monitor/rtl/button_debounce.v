`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: button_debounce
// Description: Two-stage synchronizer and hysteresis counter for mechanical
//              pushbuttons, producing a clean single-cycle strobe output.
//////////////////////////////////////////////////////////////////////////////////

module button_debounce #(
    parameter CLK_FREQ_HZ = 100_000_000,
    parameter DEBOUNCE_MS = 10
)(
    input  wire clk,
    input  wire rst,
    input  wire btn_in,
    output reg  pulse_out
);

    localparam CNT_MAX = (CLK_FREQ_HZ / 1000) * DEBOUNCE_MS;
    reg [$clog2(CNT_MAX)-1:0] timer;
    reg btn_sync_0, btn_sync_1;
    reg btn_state;

    // Two-stage synchronizer to mitigate metastability
    always @(posedge clk) begin
        btn_sync_0 <= btn_in;
        btn_sync_1 <= btn_sync_0;
    end

    // Hysteresis timing filter
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            timer     <= 0;
            btn_state <= 1'b0;
            pulse_out <= 1'b0;
        end else begin
            pulse_out <= 1'b0;
            if (btn_sync_1 != btn_state) begin
                timer <= timer + 1'b1;
                if (timer >= CNT_MAX - 1) begin
                    btn_state <= btn_sync_1;
                    timer     <= 0;
                    if (btn_sync_1 == 1'b1) begin
                        pulse_out <= 1'b1; // Single-cycle strobe
                    end
                end
            end else begin
                timer <= 0;
            end
        end
    end

endmodule
