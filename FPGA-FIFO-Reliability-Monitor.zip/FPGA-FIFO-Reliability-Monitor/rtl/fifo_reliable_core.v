`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: fifo_reliable_core
// Description: Parameterized Synchronous FIFO with runtime health diagnostics:
//              - Continuous word count tracking
//              - Programmable Almost Full / Almost Empty thresholds
//              - Sticky Underflow & Overflow error latching
//              - Word-level even parity error checking
//////////////////////////////////////////////////////////////////////////////////

module fifo_reliable_core #(
    parameter DATA_WIDTH          = 8,
    parameter ADDR_WIDTH          = 4,
    parameter DEPTH               = (1 << ADDR_WIDTH),
    parameter ALMOST_FULL_THRESH  = 14,
    parameter ALMOST_EMPTY_THRESH = 2
)(
    input  wire                  clk,
    input  wire                  rst,

    // Write Interface
    input  wire                  wr_en,
    input  wire [DATA_WIDTH-1:0] din,

    // Read Interface
    input  wire                  rd_en,
    output reg  [DATA_WIDTH-1:0] dout,

    // Status Flags
    output wire                  full,
    output wire                  empty,
    output wire                  almost_full,
    output wire                  almost_empty,
    output reg  [ADDR_WIDTH:0]   word_count,

    // Reliability & Health Diagnostics
    output reg                   overflow_error,
    output reg                   underflow_error,
    output wire                  parity_err_out
);

    // Internal Memory Array
    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    // Pointers
    reg [ADDR_WIDTH-1:0] wr_ptr;
    reg [ADDR_WIDTH-1:0] rd_ptr;

    // Combinational Flag Assignments
    assign full         = (word_count == DEPTH);
    assign empty        = (word_count == 0);
    assign almost_full  = (word_count >= ALMOST_FULL_THRESH);
    assign almost_empty = (word_count <= ALMOST_EMPTY_THRESH && word_count > 0);

    // Even Parity Checking on Current Read Output
    assign parity_err_out = ^dout;

    integer i;

    // Sequential Datapath, Pointers, and Diagnostics
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            wr_ptr          <= {ADDR_WIDTH{1'b0}};
            rd_ptr          <= {ADDR_WIDTH{1'b0}};
            word_count      <= {(ADDR_WIDTH+1){1'b0}};
            dout            <= {DATA_WIDTH{1'b0}};
            overflow_error  <= 1'b0;
            underflow_error <= 1'b0;
            for (i = 0; i < DEPTH; i = i + 1) begin
                mem[i] <= {DATA_WIDTH{1'b0}};
            end
        end else begin
            // Error Handling: Sticky Assertions
            if (wr_en && full && !rd_en) begin
                overflow_error <= 1'b1;  // Attempted write into full FIFO
            end
            if (rd_en && empty) begin
                underflow_error <= 1'b1; // Attempted read from empty FIFO
            end

            // Concurrent Read / Write Arbitration
            case ({wr_en && !full, rd_en && !empty})
                2'b10: begin // Write Only
                    mem[wr_ptr] <= din;
                    wr_ptr      <= wr_ptr + 1'b1;
                    word_count  <= word_count + 1'b1;
                end

                2'b01: begin // Read Only
                    dout       <= mem[rd_ptr];
                    rd_ptr     <= rd_ptr + 1'b1;
                    word_count <= word_count - 1'b1;
                end

                2'b11: begin // Simultaneous Write and Read
                    mem[wr_ptr] <= din;
                    dout        <= mem[rd_ptr];
                    wr_ptr      <= wr_ptr + 1'b1;
                    rd_ptr      <= rd_ptr + 1'b1;
                    // word_count remains invariant
                end

                default: begin
                    // Idle state
                end
            endcase
        end
    end

endmodule
