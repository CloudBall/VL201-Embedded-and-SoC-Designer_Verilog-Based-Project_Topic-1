`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: seven_seg_controller
// Description: Time-multiplexed 4-digit seven-segment driver with decimal
//              occupancy display and diagnostic error codes ('O', 'U').
//////////////////////////////////////////////////////////////////////////////////

module seven_seg_controller (
    input  wire       clk,         // 100 MHz reference clock
    input  wire       rst,
    input  wire [4:0] word_count,  // FIFO Occupancy (0 to 16)
    input  wire       ovf,         // Sticky Overflow Flag
    input  wire       unf,         // Sticky Underflow Flag
    output reg  [3:0] an,          // Anode enables (active-low)
    output reg  [6:0] seg          // Segments CA through CG (active-low)
);

    // Refresh rate divider (~763 Hz refresh for 4 digits -> ~190 Hz/digit)
    reg [17:0] clk_div;
    always @(posedge clk or posedge rst) begin
        if (rst)
            clk_div <= 18'd0;
        else
            clk_div <= clk_div + 1'b1;
    end

    wire [1:0] active_digit = clk_div[17:16];
    reg  [3:0] hex_to_decode;

    // Anode activation and digit selection
    always @(*) begin
        case (active_digit)
            2'b00: begin
                an = 4'b1110; // Digit 0: Units
                hex_to_decode = word_count % 10;
            end
            2'b01: begin
                an = 4'b1101; // Digit 1: Tens
                hex_to_decode = word_count / 10;
            end
            2'b10: begin
                an = 4'b1011; // Digit 2: Underflow Indicator ('U' or blank)
                hex_to_decode = unf ? 4'hE : 4'hF;
            end
            2'b11: begin
                an = 4'b0111; // Digit 3: Overflow Indicator ('O' or blank)
                hex_to_decode = ovf ? 4'hA : 4'hF;
            end
            default: begin
                an = 4'b1111;
                hex_to_decode = 4'hF;
            end
        endcase
    end

    // Cathode segment decoder (active-low segments: {a, b, c, d, e, f, g})
    always @(*) begin
        case (hex_to_decode)
            4'h0: seg = 7'b0000001; // 0
            4'h1: seg = 7'b1001111; // 1
            4'h2: seg = 7'b0010010; // 2
            4'h3: seg = 7'b0000110; // 3
            4'h4: seg = 7'b1001100; // 4
            4'h5: seg = 7'b0100100; // 5
            4'h6: seg = 7'b0100000; // 6
            4'h7: seg = 7'b0001111; // 7
            4'h8: seg = 7'b0000000; // 8
            4'h9: seg = 7'b0000100; // 9
            4'hA: seg = 7'b0000001; // 'O'
            4'hE: seg = 7'b1000001; // 'U'
            default: seg = 7'b1111111; // Blank
        endcase
    end

endmodule
