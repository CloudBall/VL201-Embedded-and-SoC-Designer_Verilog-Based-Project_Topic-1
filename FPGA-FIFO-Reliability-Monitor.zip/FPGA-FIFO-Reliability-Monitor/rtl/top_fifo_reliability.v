`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: top_fifo_reliability
// Description: Top-level integration module mapping FIFO core, debouncers,
//              seven-segment display, and status indicators onto the Artix-7 FPGA.
//////////////////////////////////////////////////////////////////////////////////

module top_fifo_reliability (
    input  wire        clk_100MHz,
    input  wire        rst_btn,       // Push Button Top (btnU)
    input  wire        btn_write,     // Push Button Center (btnC)
    input  wire        btn_read,      // Push Button Bottom (btnD)
    input  wire [7:0]  sw_data,       // Slide Switches SW[7:0]
    output wire [3:0]  an,            // Anodes AN[3:0]
    output wire [6:0]  seg,           // Cathodes CA-CG
    output wire [5:0]  led_status     // Discrete LEDs LD[5:0]
);

    wire wr_pulse, rd_pulse;
    wire [7:0] fifo_dout;
    wire full, empty, almost_full, almost_empty;
    wire ovf_error, unf_error, parity_error;
    wire [4:0] word_count;

    // Push-Button Debouncer instances
    button_debounce deb_wr (
        .clk(clk_100MHz),
        .rst(rst_btn),
        .btn_in(btn_write),
        .pulse_out(wr_pulse)
    );

    button_debounce deb_rd (
        .clk(clk_100MHz),
        .rst(rst_btn),
        .btn_in(btn_read),
        .pulse_out(rd_pulse)
    );

    // Reliable Synchronous FIFO Core instantiation
    fifo_reliable_core #(
        .DATA_WIDTH(8),
        .ADDR_WIDTH(4),
        .DEPTH(16),
        .ALMOST_FULL_THRESH(14),
        .ALMOST_EMPTY_THRESH(2)
    ) u_fifo (
        .clk(clk_100MHz),
        .rst(rst_btn),
        .wr_en(wr_pulse),
        .din(sw_data),
        .rd_en(rd_pulse),
        .dout(fifo_dout),
        .full(full),
        .empty(empty),
        .almost_full(almost_full),
        .almost_empty(almost_empty),
        .word_count(word_count),
        .overflow_error(ovf_error),
        .underflow_error(unf_error),
        .parity_err_out(parity_error)
    );

    // Status LED assignments
    assign led_status[0] = empty;
    assign led_status[1] = almost_empty;
    assign led_status[2] = almost_full;
    assign led_status[3] = full;
    assign led_status[4] = ovf_error;
    assign led_status[5] = unf_error;

    // Seven-Segment Controller instantiation
    seven_seg_controller u_display (
        .clk(clk_100MHz),
        .rst(rst_btn),
        .word_count(word_count),
        .ovf(ovf_error),
        .unf(unf_error),
        .an(an),
        .seg(seg)
    );

    // Note: To instantiate Vivado ILA in hardware testing, uncomment or include ila_0 core:
    /*
    ila_0 u_ila (
        .clk(clk_100MHz),
        .probe0(sw_data),
        .probe1(fifo_dout),
        .probe2(wr_pulse),
        .probe3(rd_pulse),
        .probe4(full),
        .probe5(empty),
        .probe6(ovf_error),
        .probe7(unf_error),
        .probe8(word_count)
    );
    */

endmodule
